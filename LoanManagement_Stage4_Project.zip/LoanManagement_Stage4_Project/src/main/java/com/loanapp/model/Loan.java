package com.loanapp.model;

public class Loan {
    private int loanId;
    private double loanAmount;
    private String status;
    private String reviewedBy;
    private String applicantUsername;
    private String applicantFname;
    private String applicantEmail;

    public int getLoanId() { return loanId; }
    public double getLoanAmount() { return loanAmount; }
    public String getStatus() { return status; }
    public String getReviewedBy() { return reviewedBy; }
    public String getApplicantUsername() { return applicantUsername; }
    public String getApplicantFname() { return applicantFname; }
    public String getApplicantEmail() { return applicantEmail; }

    public void setLoanId(int v) { loanId = v; }
    public void setLoanAmount(double v) { loanAmount = v; }
    public void setStatus(String v) { status = v; }
    public void setReviewedBy(String v) { reviewedBy = v; }
    public void setApplicantUsername(String v) { applicantUsername = v; }
    public void setApplicantFname(String v) { applicantFname = v; }
    public void setApplicantEmail(String v) { applicantEmail = v; }
}
