package com.loanapp.model;

public class User {
    private int userId;
    private String username, fname, lname, email, mobile, status, location;
    private boolean admin;

    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getFname() { return fname; }
    public String getLname() { return lname; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public String getStatus() { return status; }
    public String getLocation() { return location; }
    public boolean isAdmin() { return admin; }

    public void setUserId(int v) { userId = v; }
    public void setUsername(String v) { username = v; }
    public void setFname(String v) { fname = v; }
    public void setLname(String v) { lname = v; }
    public void setEmail(String v) { email = v; }
    public void setMobile(String v) { mobile = v; }
    public void setStatus(String v) { status = v; }
    public void setLocation(String v) { location = v; }
    public void setAdmin(boolean v) { admin = v; }
}
