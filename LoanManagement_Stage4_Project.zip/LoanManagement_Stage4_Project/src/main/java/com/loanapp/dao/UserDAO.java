package com.loanapp.dao;

import com.loanapp.model.User;
import java.util.Collections;
import java.util.List;

/** Placeholder DAO. Replace with the working Stage 3 implementation. */
public class UserDAO {
    public List<User> searchUsers(String column, String value) { return Collections.emptyList(); }
    public boolean updateUserDetails(User user) { return false; }
    public boolean updateStatus(int userId, String status) { return false; }
    public boolean updateFailedAttempts(int userId, int attempts) { return false; }
    public boolean deleteUser(int userId) { return false; }
    public User findByUsername(String username) { return null; }
}
