package com.loanapp.db;

import java.sql.Connection;
import java.sql.SQLException;

/** Configure this using your project's real JDBC setup. */
public final class DBConnection {
    private DBConnection() {}
    public static Connection getConnection() throws SQLException {
        throw new SQLException("DBConnection is a placeholder. Add your real JDBC connection settings.");
    }
}
