package com.loanapp.service;

/**
 * Placeholder notification service. Replace with the actual email implementation
 * from your Stage 3 project before relying on email delivery.
 */
public class EmailService {
    public void sendEditEmail(String email, String firstName) { System.out.println("[Email placeholder] Profile updated: " + email); }
    public void sendActivationEmail(String email, String firstName) { System.out.println("[Email placeholder] Account activated: " + email); }
    public void sendDeactivationEmail(String email, String firstName) { System.out.println("[Email placeholder] Account deactivated: " + email); }
    public void sendDeletionEmail(String email, String firstName) { System.out.println("[Email placeholder] Account deleted: " + email); }
    public void sendLoanApprovedEmail(String email, String firstName, int loanId, double amount) { System.out.println("[Email placeholder] Loan approved: #" + loanId); }
    public void sendLoanRejectedEmail(String email, String firstName, int loanId, String reason) { System.out.println("[Email placeholder] Loan rejected: #" + loanId); }
}
