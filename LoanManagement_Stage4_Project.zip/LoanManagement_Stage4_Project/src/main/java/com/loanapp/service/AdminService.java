package com.loanapp.service;

import com.loanapp.dao.LoanDAO;
import com.loanapp.dao.UserDAO;
import com.loanapp.db.DBConnection;
import com.loanapp.model.Loan;
import com.loanapp.model.User;
import com.loanapp.util.AuditLogger;
import com.loanapp.util.ValidationUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/**
 * Business logic for everything an admin can do once logged in:
 * search users, view details, edit info, activate/deactivate, delete,
 * review loan applications (Stage 4), and trigger the matching email
 * notification for each action.
 *
 * Role-based access control note: this class is only ever reached from
 * Main after login() has confirmed user.isAdmin() == true, so regular
 * users have no path to any method here.
 */
public class AdminService {

    private static final String STATUS_ACTIVE = "active";
    private static final String STATUS_INACTIVE = "inactive";

    private static final String LOAN_PENDING = "pending";
    private static final String LOAN_APPROVED = "approved";
    private static final String LOAN_REJECTED = "rejected";

    private final UserDAO userDAO = new UserDAO();
    private final LoanDAO loanDAO = new LoanDAO();
    private final EmailService emailService = new EmailService();
    private final Scanner scanner;

    public AdminService(Scanner scanner) {
        this.scanner = scanner;
    }

    public void showAdminMenu(User admin) {
        boolean running = true;
        while (running) {
            System.out.println("\\n----- ADMIN DASHBOARD (" + admin.getUsername() + ") -----");
            System.out.println("1.  Search Users");
            System.out.println("2.  View User Details");
            System.out.println("3.  Edit User Information");
            System.out.println("4.  Activate User");
            System.out.println("5.  Deactivate User");
            System.out.println("6.  Delete User");
            System.out.println("7.  View Loan Applications");
            System.out.println("8.  Approve Loan Application");
            System.out.println("9.  Reject Loan Application");
            System.out.println("10. Logout");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": searchUsers(); break;
                case "2": viewUserDetails(); break;
                case "3": editUserInformation(admin); break;
                case "4": activateUser(admin); break;
                case "5": deactivateUser(admin); break;
                case "6": deleteUser(admin); break;
                case "7": viewLoanApplications(); break;
                case "8": decideLoan(admin, LOAN_APPROVED); break;
                case "9": decideLoan(admin, LOAN_REJECTED); break;
                case "10":
                    System.out.println("Admin logged out successfully.");
                    running = false;
                    break;
                default: System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void searchUsers() {
        System.out.println("\\n===== SEARCH USERS =====");
        System.out.println("Search by: 1.First Name 2.Last Name 3.Email 4.Mobile 5.Username 6.Status");
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine().trim();
        String column = mapSearchChoiceToColumn(choice);
        if (column == null) {
            System.out.println("Invalid choice.");
            return;
        }
        System.out.print("Enter search value: ");
        String value = scanner.nextLine().trim();
        List<User> results = userDAO.searchUsers(column, value);
        if (results.isEmpty()) {
            System.out.println("No matching users found.");
            return;
        }
        System.out.println("\\nFound " + results.size() + " user(s):");
        System.out.printf("%-6s %-15s %-15s %-25s %-12s %-10s%n",
                "ID", "First Name", "Last Name", "Email", "Mobile", "Status");
        for (User u : results) {
            System.out.printf("%-6d %-15s %-15s %-25s %-12s %-10s%n",
                    u.getUserId(), u.getFname(), u.getLname(), u.getEmail(), u.getMobile(), u.getStatus());
        }
        System.out.println("(Use the Username shown above with the other menu options.)");
    }

    private String mapSearchChoiceToColumn(String choice) {
        switch (choice) {
            case "1": return "fname";
            case "2": return "lname";
            case "3": return "email";
            case "4": return "mobile";
            case "5": return "username";
            case "6": return "status";
            default: return null;
        }
    }

    private void viewUserDetails() {
        System.out.println("\\n===== VIEW USER DETAILS =====");
        User user = findRegularUserByUsernamePrompt();
        if (user == null) return;
        System.out.println("\\n--- User Details ---");
        System.out.println("Full Name : " + user.getFname() + " " + user.getLname());
        System.out.println("Email     : " + user.getEmail());
        System.out.println("Mobile    : " + user.getMobile());
        System.out.println("Location  : " + (user.getLocation() == null ? "-" : user.getLocation()));
        System.out.println("Status    : " + user.getStatus());
        System.out.println("Loan Applications:");
        printLoanApplicationsIfAny(user.getUserId());
    }

    private void printLoanApplicationsIfAny(int userId) {
        String sql = "SELECT loan_id, loan_amount, status FROM loan_applications WHERE user_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                boolean any = false;
                while (rs.next()) {
                    any = true;
                    System.out.println("  - Loan #" + rs.getInt("loan_id")
                            + " | Amount: " + rs.getDouble("loan_amount")
                            + " | Status: " + rs.getString("status"));
                }
                if (!any) System.out.println("  (No loan applications submitted yet.)");
            }
        } catch (SQLException e) {
            System.out.println("  (Could not load loan applications: " + e.getMessage() + ")");
        }
    }

    private void editUserInformation(User admin) {
        System.out.println("\\n===== EDIT USER INFORMATION =====");
        User user = findRegularUserByUsernamePrompt();
        if (user == null) return;
        System.out.println("Leave a field blank to keep its current value.");

        System.out.print("First Name [" + user.getFname() + "]: ");
        String fname = scanner.nextLine().trim();
        if (ValidationUtil.isNotEmpty(fname)) user.setFname(fname);

        System.out.print("Last Name [" + user.getLname() + "]: ");
        String lname = scanner.nextLine().trim();
        if (ValidationUtil.isNotEmpty(lname)) user.setLname(lname);

        while (true) {
            System.out.print("Mobile [" + user.getMobile() + "]: ");
            String mobile = scanner.nextLine().trim();
            if (mobile.isEmpty()) break;
            if (ValidationUtil.isValidMobile(mobile)) {
                user.setMobile(mobile);
                break;
            }
            System.out.println("Invalid mobile number. It must be exactly 10 digits.");
        }

        while (true) {
            System.out.print("Email [" + user.getEmail() + "]: ");
            String email = scanner.nextLine().trim();
            if (email.isEmpty()) break;
            if (!ValidationUtil.isValidEmail(email)) {
                System.out.println("Invalid email format.");
                continue;
            }
            user.setEmail(email);
            break;
        }

        System.out.print("Location [" + (user.getLocation() == null ? "-" : user.getLocation()) + "]: ");
        String location = scanner.nextLine().trim();
        if (ValidationUtil.isNotEmpty(location)) user.setLocation(location);

        boolean success = userDAO.updateUserDetails(user);
        if (success) {
            System.out.println("User information updated successfully.");
            emailService.sendEditEmail(user.getEmail(), user.getFname());
            AuditLogger.log(admin.getUsername(), "EDIT", user.getUsername(), "Profile fields updated");
        } else System.out.println("Failed to update user information.");
    }

    private void activateUser(User admin) {
        System.out.println("\\n===== ACTIVATE USER =====");
        User user = findRegularUserByUsernamePrompt();
        if (user == null) return;
        if (STATUS_ACTIVE.equalsIgnoreCase(user.getStatus())) {
            System.out.println("This user is already active.");
            return;
        }
        boolean success = userDAO.updateStatus(user.getUserId(), STATUS_ACTIVE);
        if (success) {
            userDAO.updateFailedAttempts(user.getUserId(), 0);
            System.out.println("User activated successfully.");
            emailService.sendActivationEmail(user.getEmail(), user.getFname());
            AuditLogger.log(admin.getUsername(), "ACTIVATE", user.getUsername(), null);
        } else System.out.println("Failed to activate user.");
    }

    private void deactivateUser(User admin) {
        System.out.println("\\n===== DEACTIVATE USER =====");
        User user = findRegularUserByUsernamePrompt();
        if (user == null) return;
        if (STATUS_INACTIVE.equalsIgnoreCase(user.getStatus())) {
            System.out.println("This user is already inactive.");
            return;
        }
        boolean success = userDAO.updateStatus(user.getUserId(), STATUS_INACTIVE);
        if (success) {
            System.out.println("User deactivated successfully.");
            emailService.sendDeactivationEmail(user.getEmail(), user.getFname());
            AuditLogger.log(admin.getUsername(), "DEACTIVATE", user.getUsername(), null);
        } else System.out.println("Failed to deactivate user.");
    }

    private void deleteUser(User admin) {
        System.out.println("\\n===== DELETE USER =====");
        User user = findRegularUserByUsernamePrompt();
        if (user == null) return;
        System.out.print("Are you sure you want to delete '" + user.getUsername() + "'? (yes/no): ");
        String confirm = scanner.nextLine().trim();
        if (!confirm.equalsIgnoreCase("yes")) {
            System.out.println("Deletion cancelled.");
            return;
        }
        String email = user.getEmail();
        String fname = user.getFname();
        boolean success = userDAO.deleteUser(user.getUserId());
        if (success) {
            System.out.println("User deleted successfully.");
            emailService.sendDeletionEmail(email, fname);
            AuditLogger.log(admin.getUsername(), "DELETE", user.getUsername(), "User permanently removed");
        } else System.out.println("Failed to delete user.");
    }

    private void viewLoanApplications() {
        System.out.println("\\n===== VIEW LOAN APPLICATIONS =====");
        System.out.println("Filter: 1.All 2.Pending 3.Approved 4.Rejected");
        System.out.print("Enter choice: ");
        String choice = scanner.nextLine().trim();
        String status;
        switch (choice) {
            case "1": status = null; break;
            case "2": status = LOAN_PENDING; break;
            case "3": status = LOAN_APPROVED; break;
            case "4": status = LOAN_REJECTED; break;
            default:
                System.out.println("Invalid choice.");
                return;
        }
        List<Loan> loans = loanDAO.findByStatus(status);
        if (loans.isEmpty()) {
            System.out.println("No loan applications found.");
            return;
        }
        System.out.println("\\nFound " + loans.size() + " application(s):");
        System.out.printf("%-8s %-15s %-12s %-10s %-15s%n",
                "Loan ID", "Applicant", "Amount", "Status", "Reviewed By");
        for (Loan l : loans) {
            System.out.printf("%-8d %-15s %-12.2f %-10s %-15s%n",
                    l.getLoanId(), l.getApplicantUsername(), l.getLoanAmount(),
                    l.getStatus(), l.getReviewedBy() == null ? "-" : l.getReviewedBy());
        }
    }

    private void decideLoan(User admin, String decision) {
        boolean approving = LOAN_APPROVED.equals(decision);
        System.out.println("\\n===== " + (approving ? "APPROVE" : "REJECT") + " LOAN APPLICATION =====");
        System.out.print("Enter Loan ID: ");
        String idText = scanner.nextLine().trim();
        int loanId;
        try {
            loanId = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            System.out.println("Loan ID must be a number.");
            return;
        }

        Loan loan = loanDAO.findById(loanId);
        if (loan == null) {
            System.out.println("No loan application found with that ID.");
            return;
        }
        if (!LOAN_PENDING.equalsIgnoreCase(loan.getStatus())) {
            System.out.println("This application has already been " + loan.getStatus() + ".");
            return;
        }
        System.out.println("Applicant : " + loan.getApplicantFname() + " (" + loan.getApplicantUsername() + ")");
        System.out.println("Amount    : " + loan.getLoanAmount());

        String remarks = null;
        if (!approving) {
            System.out.print("Reason for rejection: ");
            remarks = scanner.nextLine().trim();
            if (!ValidationUtil.isNotEmpty(remarks)) {
                System.out.println("A rejection reason is required.");
                return;
            }
        } else {
            System.out.print("Remarks (optional): ");
            String r = scanner.nextLine().trim();
            remarks = ValidationUtil.isNotEmpty(r) ? r : null;
        }

        System.out.print("Confirm " + decision + " loan #" + loanId + "? (yes/no): ");
        if (!scanner.nextLine().trim().equalsIgnoreCase("yes")) {
            System.out.println("Action cancelled.");
            return;
        }
        boolean success = loanDAO.decide(loanId, decision, admin.getUsername(), remarks);
        if (success) {
            System.out.println("Loan " + decision + " successfully.");
            if (approving) {
                emailService.sendLoanApprovedEmail(loan.getApplicantEmail(), loan.getApplicantFname(),
                        loan.getLoanId(), loan.getLoanAmount());
            } else {
                emailService.sendLoanRejectedEmail(loan.getApplicantEmail(), loan.getApplicantFname(),
                        loan.getLoanId(), remarks);
            }
            AuditLogger.log(admin.getUsername(), approving ? "LOAN_APPROVE" : "LOAN_REJECT",
                    loan.getApplicantUsername(), "Loan #" + loanId + (remarks == null ? "" : " - " + remarks));
        } else System.out.println("Failed to update the loan (it may have been processed already).");
    }

    private User findRegularUserByUsernamePrompt() {
        System.out.print("Enter Username of the user: ");
        String username = scanner.nextLine().trim();
        if (!ValidationUtil.isNotEmpty(username)) {
            System.out.println("Username cannot be empty.");
            return null;
        }
        User user = userDAO.findByUsername(username);
        if (user == null) {
            System.out.println("No user found with that username.");
            return null;
        }
        if (user.isAdmin()) {
            System.out.println("That account is an admin account and cannot be managed here.");
            return null;
        }
        return user;
    }
}
