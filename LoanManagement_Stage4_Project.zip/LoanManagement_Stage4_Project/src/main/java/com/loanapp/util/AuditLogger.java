package com.loanapp.util;

public final class AuditLogger {
    private AuditLogger() {}
    public static void log(String actor, String action, String target, String details) {
        System.out.printf("[Audit placeholder] actor=%s action=%s target=%s details=%s%n",
                actor, action, target, details == null ? "" : details);
    }
}
