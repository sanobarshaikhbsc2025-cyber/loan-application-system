package com.loanapp.util;

public final class ValidationUtil {
    private ValidationUtil() {}
    public static boolean isNotEmpty(String value) { return value != null && !value.trim().isEmpty(); }
    public static boolean isValidMobile(String mobile) { return mobile != null && mobile.matches("\\d{10}"); }
    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }
}
