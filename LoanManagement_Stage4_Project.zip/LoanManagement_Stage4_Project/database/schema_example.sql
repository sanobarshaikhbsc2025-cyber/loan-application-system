-- Example only: adapt table names, columns, and data types to your actual Stage 3 schema.
CREATE TABLE loan_applications (
    loan_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    loan_amount DECIMAL(12,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    reviewed_by VARCHAR(100) NULL,
    decision_reason VARCHAR(500) NULL,
    reviewed_at TIMESTAMP NULL,
    application_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Add a foreign key only after confirming the real user table and key:
-- ALTER TABLE loan_applications
--   ADD CONSTRAINT fk_loan_user FOREIGN KEY (user_id) REFERENCES users(user_id);
